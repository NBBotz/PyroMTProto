#  PyroMTProto - Telegram MTProto API Client Library for Python
#  Copyright (C) 2024-present PyroMTProto Contributors
#  Licensed under the GNU Lesser General Public License v3.0

import pyrogram
from pyrogram import raw, utils
from pyrogram.file_id import FileType


class RemoveProfileAudio:
    async def remove_profile_audio(
        self: "pyrogram.Client",
        audio: str,
    ):
        """Removes an audio file from the profile audio files of the current user.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            audio (``str``):
                Identifier of the audio file to be removed.
                Use :meth:`~pyrogram.Client.get_chat_audios` to get the Audio identifier.

        Returns:
            ``bool``: On success, True is returned.

        Example:
            .. code-block:: python

                # Remove audio file from profile
                await app.remove_profile_audio(file_id)

        """
        return await self.invoke(
            raw.functions.account.SaveMusic(
                id=(utils.get_input_media_from_file_id(audio, FileType.AUDIO)).id,
                unsave=True
            )
        )
