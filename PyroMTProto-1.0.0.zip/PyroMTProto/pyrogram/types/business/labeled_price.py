#  PyroMTProto - Telegram MTProto API Client Library for Python
#  Copyright (C) 2024-present PyroMTProto Contributors
#  Licensed under the GNU Lesser General Public License v3.0

import pyrogram
from pyrogram import raw

from ..object import Object


class LabeledPrice(Object):
    """This object represents a portion of the price for goods or services.

    Parameters:
        label (``str``):
            Portion label.

        amount (``int``):
            Price of the product in the smallest units of the currency (integer, **not** float/double). For example, for a price of ``US$ 1.45`` pass ``amount = 145``. See the __exp__ parameter in `currencies.json <https://core.telegram.org/bots/payments/currencies.json>`_, it shows the number of digits past the decimal point for each currency (2 for the majority of currencies).

    """

    def __init__(
        self,
        label: str,
        amount: int
    ):
        super().__init__()

        self.label = label
        self.amount = amount

    @staticmethod
    def _parse(labeled_price: "raw.types.LabeledPrice") -> "LabeledPrice":
        if isinstance(labeled_price, raw.types.LabeledPrice):
            return LabeledPrice(
                label=labeled_price.label,
                amount=labeled_price.amount
            )

    def write(self):
        return raw.types.LabeledPrice(
            label=self.label,
            amount=self.amount
        )
