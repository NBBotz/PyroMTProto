#  PyroMTProto - Telegram MTProto API Client Library for Python
#  Copyright (C) 2024-present PyroMTProto Contributors
#  Licensed under the GNU Lesser General Public License v3.0

from pyrogram import raw
from ..object import Object


class ChatPrivileges(Object):
    """Describes privileged actions an administrator is able to take in a chat.

    Parameters:
        is_anonymous (``bool``, *optional*):
            True, if the user's presence in the chat is hidden.

        can_manage_chat (``bool``, *optional*):
            True, if the administrator can access the chat event log, get boost list, see hidden supergroup and channel members, report spam messages, ignore slow mode, and send messages to the chat without paying Telegram Stars. Implied by any other administrator privilege.

        can_delete_messages (``bool``, *optional*):
            True, if the administrator can delete messages of other users.

        can_manage_video_chats (``bool``, *optional*):
            True, if the administrator can manage video chats.

        can_restrict_members (``bool``, *optional*):
            True, if the administrator can restrict, ban or unban chat members, or access supergroup statistics.

        can_promote_members (``bool``, *optional*):
            True, if the administrator can add new administrators with a subset of their own privileges or demote administrators that they have promoted, directly or indirectly (promoted by administrators that were appointed by the user).

        can_change_info (``bool``, *optional*):
            True, if the user is allowed to change the chat title, photo and other settings.

        can_invite_users (``bool``, *optional*):
            True, if the user is allowed to invite new users to the chat.

        can_post_messages (``bool``, *optional*):
            True, if the administrator can post messages in the channel, approve suggested posts, or access channel statistics; for channels only.

        can_edit_messages (``bool``, *optional*):
            True, if the administrator can edit messages of other users and can pin messages; for channels only.

        can_pin_messages (``bool``, *optional*):
            True, if the user is allowed to pin messages; for groups and supergroups only.
        
        can_post_stories (``bool``, *optional*):
            True, if the administrator can post stories to the chat.

        can_edit_stories (``bool``, *optional*):
            True, if the administrator can edit stories posted by other users, post stories to the chat page, pin chat stories, and access the chat's story archive.

        can_delete_stories (``bool``, *optional*):
            True, if the administrator can delete stories posted by other users

        can_manage_topics (``bool``, *optional*):
            True, if the user is allowed to create, rename, close, and reopen forum topics; for supergroups only.
        
        can_manage_direct_messages (``bool``, *optional*):
            True, if the administrator can manage direct messages of the channel and decline suggested posts; for channels only.

        can_manage_tags (``bool``, *optional*):
            True, if the administrator can change tags of other users; applicable to basic groups and supergroups only.

    """

    def __init__(
        self,
        *,
        is_anonymous: bool = False,
        can_manage_chat: bool = True,
        can_delete_messages: bool = False,
        can_manage_video_chats: bool = False,  # Groups and supergroups only
        can_restrict_members: bool = False,
        can_promote_members: bool = False,
        can_change_info: bool = False,
        can_invite_users: bool = False,
        can_post_messages: bool = False,  # Channels only
        can_edit_messages: bool = False,  # Channels only
        can_pin_messages: bool = False,  # Groups and supergroups only
        can_post_stories: bool = False,
        can_edit_stories: bool = False,
        can_delete_stories: bool = False,
        can_manage_topics: bool = False,  # supergroups only
        can_manage_direct_messages: bool = False,
        can_manage_tags: bool = False,
    ):
        super().__init__(None)

        self.is_anonymous: bool = is_anonymous
        self.can_manage_chat: bool = can_manage_chat
        self.can_delete_messages: bool = can_delete_messages
        self.can_manage_video_chats: bool = can_manage_video_chats
        self.can_restrict_members: bool = can_restrict_members
        self.can_promote_members: bool = can_promote_members
        self.can_change_info: bool = can_change_info
        self.can_invite_users: bool = can_invite_users
        self.can_post_messages: bool = can_post_messages
        self.can_edit_messages: bool = can_edit_messages
        self.can_pin_messages: bool = can_pin_messages
        self.can_post_stories: bool = can_post_stories
        self.can_edit_stories: bool = can_edit_stories
        self.can_delete_stories: bool = can_delete_stories
        self.can_manage_topics: bool = can_manage_topics
        self.can_manage_direct_messages: bool = can_manage_direct_messages
        self.can_manage_tags: bool = can_manage_tags

    @staticmethod
    def _parse(admin_rights: "raw.base.ChatAdminRights") -> "ChatPrivileges":
        if not admin_rights:
            return None
        return ChatPrivileges(
            can_change_info=admin_rights.change_info,
            can_post_messages=admin_rights.post_messages,
            can_edit_messages=admin_rights.edit_messages,
            can_delete_messages=admin_rights.delete_messages,
            can_restrict_members=admin_rights.ban_users,
            can_invite_users=admin_rights.invite_users,
            can_pin_messages=admin_rights.pin_messages,
            can_promote_members=admin_rights.add_admins,
            is_anonymous=admin_rights.anonymous,
            can_manage_video_chats=admin_rights.manage_call,
            can_manage_chat=admin_rights.other,
            can_manage_topics=admin_rights.manage_topics,
            can_post_stories=admin_rights.post_stories,
            can_edit_stories=admin_rights.edit_stories,
            can_delete_stories=admin_rights.delete_stories,
            can_manage_direct_messages=admin_rights.manage_direct_messages,
            can_manage_tags=admin_rights.manage_ranks,
        )

    def write(self):
        return raw.types.ChatAdminRights(
            change_info=self.can_change_info,
            post_messages=self.can_post_messages,
            edit_messages=self.can_edit_messages,
            delete_messages=self.can_delete_messages,
            ban_users=self.can_restrict_members,
            invite_users=self.can_invite_users,
            pin_messages=self.can_pin_messages,
            add_admins=self.can_promote_members,
            anonymous=self.is_anonymous,
            manage_call=self.can_manage_video_chats,
            other=self.can_manage_chat,
            manage_topics=self.can_manage_topics,
            post_stories=self.can_post_stories,
            edit_stories=self.can_edit_stories,
            delete_stories=self.can_delete_stories,
            manage_direct_messages=self.can_manage_direct_messages,
            manage_ranks=self.can_manage_tags,
        ) if self else raw.types.ChatAdminRights()
