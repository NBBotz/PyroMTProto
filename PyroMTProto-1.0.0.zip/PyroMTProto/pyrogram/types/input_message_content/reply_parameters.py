#  PyroMTProto - Telegram MTProto API Client Library for Python
#  Copyright (C) 2024-present PyroMTProto Contributors
#  Licensed under the GNU Lesser General Public License v3.0

from typing import Optional, Union

import pyrogram
from pyrogram import raw, types, utils, enums
from ..object import Object


class ReplyParameters(Object):
    """Describes reply parameters for the message that is being sent.

    You must use exactly one of ``message_id`` OR ``story_id``.

    Parameters:
        message_id  (``int``, *optional*):
            Identifier of the message that will be replied to in the current chat,
            or in the chat chat_id if it is specified

        story_id  (``int``, *optional*):
            Unique identifier for the story in the chat

        chat_id (``int`` | ``str``, *optional*):
            Unique identifier (int) or username (str) of the target chat.
            For your personal cloud (Saved Messages) you can simply use "me" or "self".
            For a contact that exists in your Telegram address book you can use his phone number (str).

        quote (``str``, *optional*):
            Quoted part of the message to be replied to; 0-1024 characters after entities parsing.
            The quote must be an exact substring of the message to be replied to, including bold, italic, underline, strikethrough, spoiler, and custom_emoji entities.
            The message will fail to send if the quote isn't found in the original message.

        quote_parse_mode (:obj:`~pyrogram.enums.ParseMode`, *optional*):
            By default, texts are parsed using both Markdown and HTML styles.
            You can combine both syntaxes together.

        quote_entities (List of :obj:`~pyrogram.types.MessageEntity`, *optional*):
            List of special entities that appear in message text, which can be specified instead of *quote_parse_mode*.

        quote_position (``int``, *optional*):
            Position of the quote in the original message in UTF-16 code units
        
        checklist_task_id (``int``, *optional*):
            Identifier of the specific checklist task to be replied to.
        
        direct_messages_topic_id (``int``, *optional*):
            Identifier of the direct messages topic to which the message will be sent; **required** if the message is sent to a direct messages chat; pass None if the chat is not a channel direct messages chat administered by the current user.

        poll_option_id (``int``, *optional*):
            Persistent identifier of the specific poll option to be replied to.

    """

    def __init__(
        self,
        *,
        message_id: int = None,
        story_id: int = None,
        chat_id: Union[int, str] = None,
        # TODO
        quote: str = None,
        quote_parse_mode: Optional["enums.ParseMode"] = None,
        quote_entities: list["types.MessageEntity"] = None,
        quote_position: int = None,
        checklist_task_id: int = None,
        direct_messages_topic_id: int = None,
        poll_option_id: int = None,
    ):
        super().__init__()

        self.message_id = message_id
        self.story_id = story_id
        self.chat_id = chat_id
        self.quote = quote
        self.quote_parse_mode = quote_parse_mode
        self.quote_entities = quote_entities
        self.quote_position = quote_position
        self.checklist_task_id = checklist_task_id
        self.direct_messages_topic_id = direct_messages_topic_id
        self.poll_option_id = poll_option_id
