#  PyroMTProto - Telegram MTProto API Client Library for Python
#  Copyright (C) 2024-present PyroMTProto Contributors
#  Licensed under the GNU Lesser General Public License v3.0

import html
import logging
import re
from html.parser import HTMLParser
from typing import Optional

import pyrogram
from pyrogram import raw
from pyrogram.enums import MessageEntityType
from pyrogram.errors import PeerIdInvalid
from . import utils

log = logging.getLogger(__name__)


class Parser(HTMLParser):
    MENTION_RE = re.compile(r"tg://user\?id=(\d+)")

    def __init__(self, client: "pyrogram.Client"):
        super().__init__()

        self.client = client

        self.text = ""
        self.entities = []
        self.tag_entities = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        extra = {}

        if tag in ["b", "strong"]:
            entity = raw.types.MessageEntityBold
        elif tag in ["i", "em"]:
            entity = raw.types.MessageEntityItalic
        elif tag in ["u", "ins"]:
            entity = raw.types.MessageEntityUnderline
        elif tag in ["s", "del", "strike"]:
            entity = raw.types.MessageEntityStrike
        elif tag == "blockquote":
            entity = raw.types.MessageEntityBlockquote
            extra["collapsed"] = bool("expandable" in attrs.keys())
        elif tag == "pre":
            entity = raw.types.MessageEntityPre
            extra["language"] = attrs.get("language", "")
        elif tag == "code":
            entity = raw.types.MessageEntityCode
            _class = attrs.get("class", "")
            active_pres = self.tag_entities.get("pre", [])
            # Check if this <code> block is nested inside an active <pre>
            if active_pres:
                if _class.startswith("language-"):
                    # Update the language of the currently open <pre> entity
                    active_pres[-1].language = _class[9:] # 9 is the length of "language-"
                    
                # Return early to intentionally skip creating a nested CODE entity.
                # (When handle_endtag hits </code>, it will safely ignore it).
                return
            # If not inside a <pre>, treat it as a standard inline code block
            entity = raw.types.MessageEntityCode
        elif tag in ["spoiler", "tg-spoiler"]:
            entity = raw.types.MessageEntitySpoiler
        elif tag == "ins":
            entity = raw.types.MessageEntityDiffInsert
        elif tag in ["del"]:
            # <del> used for diff-delete; <s>/<strike> used for strikethrough
            # Only treat as diff if it has class="diff" or data-diff attr
            if "diff" in attrs.get("class", "") or "data-diff" in attrs:
                entity = raw.types.MessageEntityDiffDelete
            else:
                entity = raw.types.MessageEntityStrike
        elif tag == "mark":
            entity = raw.types.MessageEntityDiffReplace
        elif tag == "span" and attrs.get("class", "") == "tg-spoiler":
            entity = raw.types.MessageEntitySpoiler
        elif tag == "a":
            url = attrs.get("href", "")

            mention = Parser.MENTION_RE.match(url)

            if mention:
                entity = raw.types.InputMessageEntityMentionName
                extra["user_id"] = int(mention.group(1))
            else:
                entity = raw.types.MessageEntityTextUrl
                extra["url"] = url
        elif tag == "emoji":
            entity = raw.types.MessageEntityCustomEmoji
            custom_emoji_id = int(attrs.get("id"))
            extra["document_id"] = custom_emoji_id
        elif tag == "tg-emoji":
            entity = raw.types.MessageEntityCustomEmoji
            custom_emoji_id = int(attrs.get("emoji-id"))
            extra["document_id"] = custom_emoji_id
        elif tag == "tg-time":
            entity = raw.types.MessageEntityFormattedDate
            extra["date"] = int(attrs.get("unix"))
            date_time_format = attrs.get("format", "")
            extra = utils.parse_date_time_format_tl(extra, date_time_format)
        else:
            return

        if tag not in self.tag_entities:
            self.tag_entities[tag] = []

        self.tag_entities[tag].append(entity(offset=len(self.text), length=0, **extra))

    def handle_data(self, data):
        data = html.unescape(data)

        for entities in self.tag_entities.values():
            for entity in entities:
                entity.length += len(data)

        self.text += data

    def handle_endtag(self, tag):
        try:
            self.entities.append(self.tag_entities[tag].pop())
        except (KeyError, IndexError):
            line, offset = self.getpos()
            offset += 1

            log.debug("Unmatched closing tag </%s> at line %s:%s", tag, line, offset)
        else:
            if not self.tag_entities[tag]:
                self.tag_entities.pop(tag)

    def error(self, message):
        pass


class HTML:
    def __init__(self, client: Optional["pyrogram.Client"]):
        self.client = client

    async def parse(self, text: str):
        # Strip whitespaces from the beginning and the end, but preserve closing tags
        text = re.sub(r"^\s*(<[\w<>=\s\"]*>)\s*", r"\1", text)
        text = re.sub(r"\s*(</[\w</>]*>)\s*$", r"\1", text)

        parser = Parser(self.client)
        parser.feed(utils.add_surrogates(text))
        parser.close()

        if parser.tag_entities:
            unclosed_tags = []

            for tag, entities in parser.tag_entities.items():
                unclosed_tags.append(f"<{tag}> (x{len(entities)})")

            log.info("Unclosed tags: %s", ", ".join(unclosed_tags))

        entities = []

        for entity in parser.entities:
            if isinstance(entity, raw.types.InputMessageEntityMentionName):
                try:
                    if self.client is not None:
                        entity.user_id = await self.client.resolve_peer(entity.user_id)
                except PeerIdInvalid:
                    continue

            entities.append(entity)

        # Remove zero-length entities
        entities = list(filter(lambda x: x.length > 0, entities))

        return {
            "message": utils.remove_surrogates(parser.text),
            "entities": sorted(entities, key=lambda e: e.offset) or None
        }

    @staticmethod
    def unparse(text: str, entities: list):
        def parse_one(entity):
            """
            Parses a single entity and returns (start_tag, start), (end_tag, end)
            """
            entity_type = entity.type
            start = entity.offset
            end = start + entity.length

            if entity_type in (
                MessageEntityType.BOLD,
                MessageEntityType.ITALIC,
                MessageEntityType.UNDERLINE,
                MessageEntityType.STRIKETHROUGH,
            ):
                name = entity_type.name[0].lower()
                start_tag = f"<{name}>"
                end_tag = f"</{name}>"
            elif entity_type == MessageEntityType.PRE:
                name = entity_type.name.lower()
                language = getattr(entity, "language", "") or ""
                start_tag = f'<pre><code class="language-{language}">' if language else f"<{name}>"
                end_tag = f"</code></pre>" if language else f"</{name}>"
            elif entity_type == MessageEntityType.EXPANDABLE_BLOCKQUOTE:
                name = "blockquote"
                start_tag = f"<{name} expandable>"
                end_tag = f"</{name}>"
            elif entity_type in (
                MessageEntityType.CODE,
                MessageEntityType.BLOCKQUOTE,
            ):
                name = entity_type.name.lower()
                start_tag = f"<{name}>"
                end_tag = f"</{name}>"
            elif entity_type == MessageEntityType.SPOILER:
                start_tag = "<tg-spoiler>"
                end_tag = "</tg-spoiler>"
            elif entity_type == MessageEntityType.TEXT_LINK:
                url = entity.url
                start_tag = f'<a href="{url}">'
                end_tag = "</a>"
            elif entity_type == MessageEntityType.TEXT_MENTION:
                user = entity.user
                start_tag = f'<a href="tg://user?id={user.id}">'
                end_tag = "</a>"
            elif entity_type == MessageEntityType.CUSTOM_EMOJI:
                custom_emoji_id = entity.custom_emoji_id
                start_tag = f'<tg-emoji emoji-id="{custom_emoji_id}">'
                end_tag = "</emoji>"
            elif entity_type == MessageEntityType.DATE_TIME:
                date = entity.unix_time
                dtf = entity.date_time_format
                start_tag = f'<tg-time unix="{date}" format="{dtf}">'
                end_tag = "</tg-time>"
            elif entity_type == MessageEntityType.DIFF_TYPE_INSERT:
                start_tag = "<ins>"
                end_tag = "</ins>"
            elif entity_type == MessageEntityType.DIFF_TYPE_DELETE:
                start_tag = "<del>"
                end_tag = "</del>"
            elif entity_type == MessageEntityType.DIFF_TYPE_REPLACE:
                start_tag = "<mark>"
                end_tag = "</mark>"
            else:
                return

            return (start_tag, start), (end_tag, end)

        def recursive(entity_i: int) -> int:
            """
            Takes the index of the entity to start parsing from, returns the number of parsed entities inside it.
            Uses entities_offsets as a stack, pushing (start_tag, start) first, then parsing nested entities,
            and finally pushing (end_tag, end) to the stack.
            No need to sort at the end.
            """
            this = parse_one(entities[entity_i])
            if this is None:
                return 1
            (start_tag, start), (end_tag, end) = this
            entities_offsets.append((start_tag, start))
            internal_i = entity_i + 1
            # while the next entity is inside the current one, keep parsing
            while internal_i < len(entities) and entities[internal_i].offset < end:
                internal_i += recursive(internal_i)
            entities_offsets.append((end_tag, end))
            return internal_i - entity_i

        text = utils.add_surrogates(text)

        entities_offsets = []

        # probably useless because entities are already sorted by telegram
        entities.sort(key=lambda e: (e.offset, -e.length))

        # main loop for first-level entities
        i = 0
        while i < len(entities):
            i += recursive(i)

        if entities_offsets:
            last_offset = entities_offsets[-1][1]
            # no need to sort, but still add entities starting from the end
            for entity, offset in reversed(entities_offsets):
                text = text[:offset] + entity + html.escape(text[offset:last_offset]) + text[last_offset:]
                last_offset = offset

        return utils.remove_surrogates(text)
